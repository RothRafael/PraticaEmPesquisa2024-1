public class LpcSimulationSystem {
	private static int iterationsSE;
	private static int numErrors, elementoInicial = 0, numElementsLpc = 48;
	private static long numberOfDecodigns = 0, errorSeDecoding = 0;
	private static Lpc initialLpc;
	private static LpcWithErrror lpcWithErrors;
	private static long numCombinations, percentageLP = ~0;

	private static void errorGenerator(int errorIndex, int errorPattern[], int elementIndex) throws Exception 
	{ 
		if(errorIndex == numErrors) 
		{ 
			lpcWithErrors = new LpcWithErrror(initialLpc, errorPattern);

			DecoderLpc.decodingSE(iterationsSE, lpcWithErrors);
			numberOfDecodigns++;
			
//			printSimulationPercentage(); // Apenas para acompanhar o tempo de execu��o
			if(!initialLpc.isEqual(lpcWithErrors))
				errorSeDecoding++;
			return; 
		} 
		if(elementIndex >= numElementsLpc) 
			return;
		errorPattern[errorIndex] = elementIndex; 
		errorGenerator(errorIndex+1, errorPattern, elementIndex+1); 
		errorGenerator(errorIndex, errorPattern, elementIndex+1); 
	}

	private static void printSimulationPercentage() {
		double percentageD = ((double)numberOfDecodigns * 100) / numCombinations;
		long percentageL = (long) percentageD;
		if(percentageLP != percentageL)
		{
			percentageLP = percentageL;
			System.out.print(percentageL + " ");
		}
	}
	private static void setInitialLpc() throws Exception {
		int D[][] = {	{0, 0, 0, 0}, 
						{0, 0, 0, 0},
						{0, 0, 0, 0},
						{0, 0, 0, 0}, };
		initialLpc = new Lpc(D);
	}
	private static void printTestIdentification() {
		String str = "\nAlgSE" + iterationsSE + "_";
		System.out.println(str + ": #Errors=" + numErrors);
	}
	private static void printResults() {
	    System.out.println("\n\tnumberOfDecodigns = " + numberOfDecodigns);
	    System.out.println("\terrorSeDecoding = " + errorSeDecoding);
	}
	private static void setNumberOfErrors(int nE) {
		numErrors = nE;
		int nEP = numElementsLpc;
		long numerator = 1, denominator = 1;
		for(int k=0; k<numErrors; k++) {
			numerator = numerator * nEP;
			denominator = denominator * nE;
			nE--;
			nEP--;
		}
		numCombinations = numerator / denominator;
	}
	private static void setIterationsSE(int numberOfIterations) {
		iterationsSE = numberOfIterations;
	}
	private static void resetSimulationData() {
		numberOfDecodigns = 0;
		errorSeDecoding = 0;
	}
	private static void setErrorInterval(int inicio, int fim) {
		elementoInicial = inicio;
		numElementsLpc = fim;
	}
	public static void main(String[] args) throws Exception {
		setInitialLpc();
		setErrorInterval(0, 48);  // O default � (0, 48) ==> Todos os bits do LPC
		for(int numberOfErrors=0; numberOfErrors<=7; numberOfErrors++) {
			setNumberOfErrors(numberOfErrors);
			for(int numberOfIterations=0; numberOfIterations<=3; numberOfIterations++) {
				setIterationsSE(numberOfIterations);
				printTestIdentification();
				resetSimulationData();
				errorGenerator(0, new int[numErrors], elementoInicial);
				printResults();
			}
		}
	}
}