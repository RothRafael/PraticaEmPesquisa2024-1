public class DecoderLpc {
	public static void decodingSE(int iterationsSE, LpcWithErrror lpc) {
		for(int cont=0; cont<=iterationsSE; cont++) {
			ApplyHammingOnRows(lpc);
			ApplyHammingOnColumns(lpc);
		}
	}
	private static void ApplyHammingOnRows(LpcWithErrror lpc) {
		boolean done = false;
		for(int k=0; k<4; k++) {
			if(lpc.SEr[k]==true) {
				int add = lpc.EAr[k];
				if(add==3 || (add >= 5 && add <= 7))
				{
					add = (add==3) ? 0 : add - 4;
					lpc.D[k][add] = lpc.D[k][add]==0 ? 1 : 0;
					done = true;
				}
			}
		}
		if(done)
			lpc.recomputeControlVariables();
	}
	private static void ApplyHammingOnColumns(LpcWithErrror lpc) {
		boolean done = false;
		for(int k=0; k<4; k++) {
			if(lpc.SEc[k]==true) {
				int add = lpc.EAc[k];
				if(add==3 || (add >= 5 && add <= 7))
				{
					add = (add==3) ? 0 : add - 4;
					lpc.D[add][k] = lpc.D[add][k]==0 ? 1 : 0;
					done = true;
				}
			}
		}
		if(done)
			lpc.recomputeControlVariables();
	}

}
