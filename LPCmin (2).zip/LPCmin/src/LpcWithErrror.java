public class LpcWithErrror extends Lpc
{
	public int recCr[][] = new int[4][3];
	public int recPr[] = new int[4];
	public int recCc[][] = new int[3][4];
	public int recPc[] = new int[4];

	public int sCr[][] = new int[4][3];
	public int sPr[] = new int[4];
	public int sCc[][] = new int[3][4];
	public int sPc[] = new int[4];
	public int sCrq[] = new int[4];
	public int sCcq[] = new int[4];

	public int EAr[] = new int[4];
	public int EAc[] = new int[4];
	public boolean SEr[] = new boolean[4];
	public boolean DEr[] = new boolean[4];
	public boolean SEc[] = new boolean[4];
	public boolean DEc[] = new boolean[4];

	public LpcWithErrror(Lpc initialLpc, int errorPattern[]) throws Exception {
		super(initialLpc.D);
		setErrorPattern(errorPattern);
		recomputeControlVariables();
	}
	public void recomputeControlVariables() {
		recomputeCheckBitsAndParity();
		computeSyndromes();
		computeErrorAddress();
		computeSE_DE();
	}
	public void recomputeCheckBitsAndParity() {
		for(int k=0; k<4; k++) {
			recCr[k][0] = D[k][1] ^ D[k][2] ^ D[k][3];
			recCr[k][1] = D[k][0] ^ D[k][2] ^ D[k][3];
			recCr[k][2] = D[k][0] ^ D[k][1] ^ D[k][3];
			recPr[k] =  D[k][0] ^ D[k][1] ^ D[k][2] ^ D[k][3] ^ Cr[k][0] ^ Cr[k][1] ^ Cr[k][2];
		}
		for(int k=0; k<4; k++) {
			recCc[0][k] = D[1][k] ^ D[2][k] ^ D[3][k];
			recCc[1][k] = D[0][k] ^ D[2][k] ^ D[3][k];
			recCc[2][k] = D[0][k] ^ D[1][k] ^ D[3][k];
			recPc[k] =  D[0][k] ^ D[1][k] ^ D[2][k] ^ D[3][k] ^ Cc[0][k] ^ Cc[1][k] ^ Cc[2][k];
		}
	}
	public void computeSyndromes() {
		for(int k=0; k<4; k++) {
			sPr[k] = Pr[k] == recPr[k] ? 0 : 1;
			sPc[k] = Pc[k] == recPc[k] ? 0 : 1;
			for(int t=0; t<3; t++) {
				sCr[k][t] = Cr[k][t] == recCr[k][t] ? 0 : 1;
				sCc[t][k] = Cc[t][k] == recCc[t][k] ? 0 : 1;
			}
		}
		for(int k=0; k<4; k++) {
			sCrq[k] = (sCr[k][0]==1 || sCr[k][1]==1 || sCr[k][2]==1) ? 1 : 0;
			sCcq[k] = (sCc[0][k]==1 || sCc[1][k]==1 || sCc[2][k]==1) ? 1 : 0;
		}
	}
	public void computeErrorAddress() {
		for(int k=0; k<4; k++) {
			EAr[k] = sCr[k][0] * 4 + sCr[k][1] * 2 + sCr[k][2];
			EAc[k] = sCc[0][k] * 4 + sCc[1][k] * 2 + sCc[2][k];
		}
	}
	public void computeSE_DE() {
		for(int k=0; k<4; k++) {
			SEr[k] = sCrq[k]==1 && sPr[k]==1;
			DEr[k] = sCrq[k]==1 && sPr[k]==0;
			SEc[k] = sCcq[k]==1 && sPc[k]==1;
			DEc[k] = sCcq[k]==1 && sPc[k]==0;
		}
	}
	private void setErrorPattern(int errorPattern[]) throws Exception {
		for(int k = 0; k < errorPattern.length; k++)
			setError(errorPattern[k]);
	}
	private static int invertBit(int value) {
		return value == 0 ? 1 : 0;
	}
	private void setError(int errorPosition) throws Exception {
		int row, column;
		if(errorPosition < 16) {
			row = errorPosition / 4;
			column = errorPosition % 4;
			D[row][column] = invertBit(D[row][column]);
		}
		else if(errorPosition >= 16 && errorPosition < 28) {
			errorPosition -= 16;
			row = errorPosition / 3;
			column = errorPosition % 3;
			Cr[row][column] = invertBit(Cr[row][column]);
		}
		else if(errorPosition >= 28 && errorPosition < 32) {
			errorPosition -= 28;
			Pc[errorPosition] = invertBit(Pc[errorPosition]);
		}
		else if(errorPosition >= 32 && errorPosition < 44) {
			errorPosition -= 32;
			row = errorPosition / 4;
			column = errorPosition % 4;
			Cc[row][column] = invertBit(Cc[row][column]);
		}
		else if(errorPosition >= 44 && errorPosition < 48) {
			errorPosition -= 44;
			Pr[errorPosition] = invertBit(Pr[errorPosition]);
		}
		else
			throw new Exception("Error position = " + errorPosition);
	}
	public String toString() {
		String str = "   D0 1 2 3 C0 1 2 P sC0 1 2 sP sCq SE DE Add\n";
		for(int k=0; k<4; k++) {
			str = str + "D" + k + " [" + D[k][0] + " " + D[k][1] + " " + D[k][2] + " " + 
						D[k][3] + "][" + Cr[k][0] + " " + Cr[k][1] + " " + 
						Cr[k][2] + "]" + Pr[k];
			str = str + "  [" + sCr[k][0] + " " + sCr[k][1] + " " + sCr[k][2] + "  " + sPr[k] + "]";
			str = str + " " + sCrq[k] + "  ";
			str = str + "[" + (SEr[k]==true?1:0) + " " + (DEr[k]==true?1:0) + "] " + EAr[k] + "\n";
		}
		for(int k=0; k<3; k++) {
			str = str + "C" + k + " [" + Cc[k][0] + " " + Cc[k][1] + " " + Cc[k][2] + " " + 
					Cc[k][3] + "]\n";
		}
		str = str + "P   " + Pc[0] + " " + Pc[1] + " " + Pc[2] + " " + Pc[3] + "\n";
		for(int k=0; k<3; k++) {
			str = str + "sC" + k + "[" + sCc[k][0] + " " + sCc[k][1] + " " + sCc[k][2] + " " + 
					sCc[k][3] + "]\n";
		}
		str = str + "sP [" + sPc[0] + " " + sPc[1] + " " + sPc[2] + " " + sPc[3] + "]\n";
		str = str + "sCq " + sCcq[0] + " " + sCcq[1] + " " + sCcq[2] + " " + sCcq[3] + "\n";
		str = str + "SE ["; 
		for(int k=0; k<4; k++) {
			str = str + (SEc[k]==true?1:0);
			str = str + (k<3 ? " " : "]\n");
		}
		str = str + "DE ["; 
		for(int k=0; k<4; k++) {
			str = str + (DEc[k]==true?1:0);
			str = str + (k<3 ? " " : "]\n");
		}
		str = str + "Add " + EAc[0] + " " + EAc[1] + " " + EAc[2] + " " + EAc[3] + "\n";
		return str;
	}
}

