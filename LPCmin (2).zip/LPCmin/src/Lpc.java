public class Lpc {
	public int D[][] = new int[4][4];
	public int Cr[][] = new int[4][3];
	public int Pr[] = new int[4];
	public int Cc[][] = new int[3][4];
	public int Pc[] = new int[4];
	
	public Lpc(int D[][]) throws Exception {
		for(int r=0; r<4; r++)
			for(int c=0; c<4; c++)
				this.D[r][c] = D[r][c];
		encodeColumn();
		encodeRow();
	}
	private void encodeColumn() {
		for(int k=0; k<4; k++) {
			Cc[0][k] = D[1][k] ^ D[2][k] ^ D[3][k];
			Cc[1][k] = D[0][k] ^ D[2][k] ^ D[3][k];
			Cc[2][k] = D[0][k] ^ D[1][k] ^ D[3][k];
			Pc[k] =  D[0][k] ^ D[1][k] ^ D[2][k] ^ D[3][k] ^ Cc[0][k] ^ Cc[1][k] ^ Cc[2][k];
		}
	}
	private void encodeRow() {
		for(int k=0; k<4; k++) {
			Cr[k][0] = D[k][1] ^ D[k][2] ^ D[k][3];
			Cr[k][1] = D[k][0] ^ D[k][2] ^ D[k][3];
			Cr[k][2] = D[k][0] ^ D[k][1] ^ D[k][3];
			Pr[k] =  D[k][0] ^ D[k][1] ^ D[k][2] ^ D[k][3] ^ Cr[k][0] ^ Cr[k][1] ^ Cr[k][2];
		}
	}
	public boolean isEqual(Lpc plc) {
		for(int k=0; k<4; k++) {
			for(int j=0; j<4; j++) {
				if(D[k][j] != plc.D[k][j])
					return false;
			}
		}
		return true;
	}
	public String toString() {
		String str = "";
		for(int k=0; k<4; k++) {
			str = str + "[" + D[k][0] + " " + D[k][1] + " " + D[k][2] + " " + 
						D[k][3] + "][" + Cr[k][0] + " " + Cr[k][1] + " " + 
						Cr[k][2] + "] " + Pr[k] + "\n";
		}
		for(int k=0; k<3; k++) {
			str = str + "[" + Cc[k][0] + " " + Cc[k][1] + " " + Cc[k][2] + " " + 
					Cc[k][3] + "]\n";
		}
		str = str + " " + Pc[0] + " " + Pc[1] + " " + Pc[2] + " " + Pc[3] + "\n";
		return str;
	}
}
